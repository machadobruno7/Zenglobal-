import React from 'react'
export default function App(){
  return (
    <div style={{padding:16,fontFamily:'Inter, system-ui, sans-serif'}}>
      <h1>ZenGlobal Manager</h1>
      <p>Dashboard inicial. Conecte seu Firebase aqui.</p>
      <ul>
        <li>📊 Métricas</li>
        <li>🧘 Conteúdos</li>
        <li>🧑‍⚕️ Terapeutas</li>
        <li>👤 Usuários</li>
        <li>🔔 Notificações</li>
      </ul>
    </div>
  )
}
