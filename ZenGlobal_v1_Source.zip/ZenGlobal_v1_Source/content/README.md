Coloque aqui os conteúdos (MD/áudios). Depois envie ao Firebase Storage e referencie no Firestore.
