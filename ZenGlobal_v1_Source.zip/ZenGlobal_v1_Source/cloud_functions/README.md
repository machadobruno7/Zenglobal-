Cloud Functions – use para notificações, custom claims e webhooks de pagamento.
