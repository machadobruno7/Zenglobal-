// Gerado pelo FlutterFire CLI. Rode: flutterfire configure
class DefaultFirebaseOptions {
  static dynamic get currentPlatform => throw UnimplementedError('Configure o FlutterFire: flutterfire configure');
}
