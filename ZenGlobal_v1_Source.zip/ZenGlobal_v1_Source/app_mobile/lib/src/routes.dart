import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/levels.dart';
import 'screens/player.dart';
import 'screens/journey.dart';
import 'screens/therapists.dart';
import 'screens/settings.dart';
import 'screens/spiritual.dart';

final Map<String, WidgetBuilder> routes = {
  '/home': (_) => const HomeScreen(),
  '/levels': (_) => const LevelsScreen(),
  '/player': (_) => const PlayerScreen(),
  '/journey': (_) => const JourneyScreen(),
  '/therapists': (_) => const TherapistsScreen(),
  '/settings': (_) => const SettingsScreen(),
  '/spiritual': (_) => const SpiritualScreen(),
};
