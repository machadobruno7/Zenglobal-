import 'package:flutter/material.dart';

class ZenTheme {
  static const brand = Color(0xFF7FE1C3);
  static const gold = Color(0xFFFFD966);

  static final light = ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.light),
    useMaterial3: true,
    scaffoldBackgroundColor: Colors.white,
  );

  static final dark = ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.dark),
    useMaterial3: true,
  );
}
