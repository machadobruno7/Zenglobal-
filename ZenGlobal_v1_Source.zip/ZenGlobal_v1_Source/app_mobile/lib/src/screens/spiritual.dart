import 'package:flutter/material.dart';

class SpiritualScreen extends StatelessWidget {
  const SpiritualScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Conexão Interior ✨')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(title: Text('Mensagem do dia'), subtitle: Text('Respire: você está sustentado por uma força amorosa.')),
          Divider(),
          ListTile(title: Text('Sessão 1 · Gratidão nas pequenas coisas'), subtitle: Text('8 minutos · música ambiente')),
          ListTile(title: Text('Sessão 2 · Entrega e confiança'), subtitle: Text('10 minutos · voz calma')),
          ListTile(title: Text('Sessão 3 · Silêncio que acolhe'), subtitle: Text('12 minutos · foco e paz')),
        ],
      ),
    );
  }
}
