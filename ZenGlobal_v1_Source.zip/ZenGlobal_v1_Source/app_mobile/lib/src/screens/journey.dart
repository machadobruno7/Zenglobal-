import 'package:flutter/material.dart';

class JourneyScreen extends StatelessWidget {
  const JourneyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Minha Jornada')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          ListTile(title: Text('Progresso semanal'), subtitle: Text('Humor 7.4 · Energia 7.0 · Estresse 3.1')),
          Divider(),
          ListTile(title: Text('Insight'), subtitle: Text('Senti a luz no peito expandir com a respiração.')),
          Divider(),
          ListTile(title: Text('Foto simbólica'), subtitle: Text('🌅 Luz dourada ao amanhecer')),
        ],
      ),
    );
  }
}
