import 'package:flutter/material.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Player')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Respiração – Primeiro Contato', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            Container(
              height: 180,
              width: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(colors: [Color(0xFFFFD966), Color(0xFF7FE1C3)]),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 18)],
              ),
              child: const Icon(Icons.play_arrow, size: 96, color: Colors.black87),
            ),
            const SizedBox(height: 16),
            const Text('“A respiração é o fio invisível que costura corpo, mente e energia.”'),
            const Spacer(),
            Row(children: [
              Expanded(child: ElevatedButton(onPressed: (){}, child: const Text('Reproduzir'))),
              const SizedBox(width: 8),
              OutlinedButton(onPressed: (){}, child: const Text('Trilha')),
              const SizedBox(width: 8),
              IconButton(onPressed: (){}, icon: const Icon(Icons.star_border)),
            ]),
          ],
        ),
      ),
    );
  }
}
