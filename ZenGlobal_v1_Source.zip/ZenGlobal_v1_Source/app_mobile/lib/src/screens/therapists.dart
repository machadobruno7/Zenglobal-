import 'package:flutter/material.dart';

class TherapistsScreen extends StatelessWidget {
  const TherapistsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = [
      {'name':'Camila Rocha','spec':'Psicóloga','price':'R$ 180/sessão'},
      {'name':'Ricardo Alves','spec':'Terapia energética','price':'R$ 220/sessão'},
      {'name':'Ana Lima','spec':'Sono & Ansiedade','price':'R$ 200/sessão'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Terapeutas')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (_, i) => ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(items[i]['name']!),
          subtitle: Text('${items[i]['spec']} · ${items[i]['price']}'),
          trailing: ElevatedButton(onPressed: (){}, child: const Text('Agendar')),
        ),
        separatorBuilder: (_, __) => const Divider(),
      ),
    );
  }
}
