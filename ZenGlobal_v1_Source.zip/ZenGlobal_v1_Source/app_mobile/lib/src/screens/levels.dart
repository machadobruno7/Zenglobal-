import 'package:flutter/material.dart';

class LevelsScreen extends StatelessWidget {
  const LevelsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final levels = [
      'Nível 1 · Respiração & Foco',
      'Nível 2 · Consciência Corporal',
      'Nível 3 · Energia Vital',
      'Nível 4 · Expansão Energética',
      'Nível 5 · Tantra & União',
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Jornadas')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: levels.length,
        itemBuilder: (_, i) => ListTile(
          title: Text(levels[i]),
          subtitle: const Text('10 sessões · narração IA · trilhas'),
          trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16),
          onTap: ()=>Navigator.pushNamed(context, '/player'),
        ),
        separatorBuilder: (_, __) => const Divider(height: 1),
      ),
    );
  }
}
