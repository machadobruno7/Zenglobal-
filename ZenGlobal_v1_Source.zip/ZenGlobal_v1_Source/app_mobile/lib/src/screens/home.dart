import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ZenGlobal')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Como você está hoje?', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 12),
            const Text('Check-in rápido (humor, estresse, energia)'),
            const Spacer(),
            Row(children:[
              Expanded(child: ElevatedButton(
                onPressed: ()=>Navigator.pushNamed(context, '/player'),
                child: const Text('Começar prática'),
              )),
              const SizedBox(width: 8),
              OutlinedButton(onPressed: ()=>Navigator.pushNamed(context, '/levels'), child: const Text('Ver jornadas')),
            ]),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        onDestinationSelected: (i){
          switch(i){
            case 0: Navigator.pushReplacementNamed(context, '/home'); break;
            case 1: Navigator.pushReplacementNamed(context, '/levels'); break;
            case 2: Navigator.pushReplacementNamed(context, '/journey'); break;
            case 3: Navigator.pushReplacementNamed(context, '/therapists'); break;
            case 4: Navigator.pushReplacementNamed(context, '/settings'); break;
          }
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.spa_outlined), label: 'Práticas'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Jornada'),
          NavigationDestination(icon: Icon(Icons.medical_information_outlined), label: 'Terapeutas'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Config'),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: ()=>Navigator.pushNamed(context, '/spiritual'),
        label: const Text('✨ Espiritualidade'),
        icon: const Icon(Icons.auto_awesome),
      ),
    );
  }
}
