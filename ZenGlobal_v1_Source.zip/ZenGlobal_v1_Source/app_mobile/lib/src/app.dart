import 'package:flutter/material.dart';
import 'routes.dart';
import 'theme.dart';

class ZenGlobalApp extends StatelessWidget {
  const ZenGlobalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ZenGlobal',
      theme: ZenTheme.light,
      darkTheme: ZenTheme.dark,
      themeMode: ThemeMode.system,
      routes: routes,
      initialRoute: '/home',
      debugShowCheckedModeBanner: false,
    );
  }
}
