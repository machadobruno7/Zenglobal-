# ZenGlobal v1 — Código Base (Flutter + Firebase + Admin)

## Pastas
- /app_mobile — App Flutter (Android/iOS/Web)
- /admin_panel — Painel Admin (React + Vite + Firebase Web)
- /cloud_functions — Placeholder para Functions
- /content — Seus conteúdos (MD/áudio)

## App (Flutter)
```
cd app_mobile
dart pub global activate flutterfire_cli
flutterfire configure
flutter pub get
flutter run
```
Web:
```
flutter build web
```

## Admin (React)
```
cd admin_panel
npm i
npm run dev
```

## Push para o GitHub
```
git init
git branch -M main
git remote add origin https://github.com/machadobruno7/Zenglobal-.git
git add .
git commit -m "Initial commit - ZenGlobal v1"
git push -u origin main
```
