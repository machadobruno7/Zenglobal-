# 🌿 ZenGlobal — Railway Ready

Aplicativo completo de bem-estar e meditação com IA.

## 🚀 Deploy fácil (Railway)
1. Acesse https://railway.app e faça login.
2. Crie novo projeto → **Deploy from GitHub** (ou suba este ZIP).
3. Adicione variáveis:
   - `DATABASE_URL` (PostgreSQL criado pela Railway)
   - `JWT_SECRET=zenglobal_superseguro`
   - (Opcional) chaves de IA, Cloudinary, SMTP.
4. Railway detecta automaticamente Node + Prisma e publica tudo.

✅ App acessível em: `https://zenglobal.up.railway.app`